package Obstacles;

import Entity.Entity;
import main.GamePanel;

public class Bullet extends Entity {

    public Bullet(GamePanel gp){
        super(gp);

        speed = 4;
    }
}
