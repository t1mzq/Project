package Entity;

import main.GamePanel;

public class Entity {
    public int x,y;
    public int speed;

    public Entity(GamePanel gp) {
    }

    public Entity() {
    }
}
